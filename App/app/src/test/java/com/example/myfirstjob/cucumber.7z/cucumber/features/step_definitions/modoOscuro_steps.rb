Dado('que el usuario ha abierto las opciones e indicado que quiere cambiar a modo oscuro') do
  //TODO
end

Cuando('el usuario haga click sobre el botón de modo oscuro') do
  //TODO
end

Entonces('la aplicación cambia a modo oscuro') do
  //TODO
end